export default interface ApiResource {
  Name: string;
  Scopes?: string[];
  ApiSecrets?: string[];
}
