export default interface Claim {
  Type: string;
  Value: string;
  ValueType?: string;
}
